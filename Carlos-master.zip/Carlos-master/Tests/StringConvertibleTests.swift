import Foundation
import Quick
import Nimble
import Carlos

class StringConvertibleTests: QuickSpec {
  override func spec() {
    describe("String values") {
      let value = "this is the value"
      
      it("should return self") {
        expect(value.toString()).to(equal(value))
      }
    }
    
    describe("NSString values") {
      let value = "this is the value"
      
      it("should return self") {
        expect(value.toString()).to(equal(value))
      }
    }
  }
}
