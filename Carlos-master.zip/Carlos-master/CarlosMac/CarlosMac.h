//
//  CarlosMac.h
//  CarlosMac
//
//  Created by Vittorio Monaco on 29/08/15.
//  Copyright © 2015 WeltN24. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for CarlosMac.
FOUNDATION_EXPORT double CarlosMacVersionNumber;

//! Project version string for CarlosMac.
FOUNDATION_EXPORT const unsigned char CarlosMacVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CarlosMac/PublicHeader.h>

#import <CarlosMac/NSKeyedUnarchiver+SwiftUtilities.h>