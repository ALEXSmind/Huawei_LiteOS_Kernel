//
//  CarlosTv.h
//  CarlosTv
//
//  Created by Vittorio Monaco on 03/10/15.
//  Copyright © 2015 WeltN24. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CarlosTv.
FOUNDATION_EXPORT double CarlosTvVersionNumber;

//! Project version string for CarlosTv.
FOUNDATION_EXPORT const unsigned char CarlosTvVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CarlosTv/PublicHeader.h>

#import <CarlosTv/NSKeyedUnarchiver+SwiftUtilities.h>