import Foundation
import WatchKit

class CountryRow: NSObject {
  @IBOutlet var countryName: WKInterfaceLabel!
  @IBOutlet var flagImage: WKInterfaceImage!
}