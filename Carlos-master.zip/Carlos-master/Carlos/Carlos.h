#import <UIKit/UIKit.h>

//! Project version number for Carlos.
FOUNDATION_EXPORT double CarlosVersionNumber;

//! Project version string for Carlos.
FOUNDATION_EXPORT const unsigned char CarlosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Carlos/PublicHeader.h>

#import <Carlos/NSKeyedUnarchiver+SwiftUtilities.h>
#import <CommonCrypto/CommonCrypto.h>
